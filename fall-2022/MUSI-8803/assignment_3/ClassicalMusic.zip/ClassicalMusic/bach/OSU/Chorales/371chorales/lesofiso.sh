# for file in *.krn
# do
# 	solfa -x $file > $file.solfa
# done

