# This function takes in a matrix A and a vector v and writes their product into the vector v
function u_is_A_times_v!(u, A, v)
    # Write your function here! 
end

# This function takes in matrices ABC and writes B times C into the matrix A
function A_is_B_times_C!(A, B, C)
    # Write your function here! 
end

